import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent{
    pro_temp:products[]=[];
    @Input() 
    feild_selected:string="";
    sortedArray:products[]=[]
    public proObj:products[]=[
      {pname:"abc",price:30,qty:3},
      {pname:"xyz",price:45,qty:34},
      {pname:"sam",price:43,qty:45},
      {pname:"abc_nas",price:43,qty:45},
      {pname:"cam",price:23,qty:54},
      {pname:"jam",price:324,qty:43}
    ];

    ngOnChanges():void{
     console.log("feild_selected",this.feild_selected)
     
        if(this.feild_selected=="product name"){      
          
          this.sortedArray = this.proObj.sort(function(a, b){        
            let x = a.pname.toLowerCase();       
             let y = b.pname.toLowerCase();       
             if (x < y) {return -1;}      
             if (x > y) {return 1;}        
             return 0;    
            });   
          }    
        if(this.feild_selected=="unit price"){  
              this.sortedArray = this.proObj.sort((a, b) => {        return a.price - b.price;    }); 
         }
        
         if(this.feild_selected=="unit in stock"){  
               this.sortedArray = this.proObj.sort((a, b) => {        return a.qty - b.qty;    }); 
          }  


    }
}

class products{
  pname:string="";
  price:number=0;
  qty:number=0;

}
