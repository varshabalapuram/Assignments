import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  sort_by:string="";

    // public empObj:employee[]=[
    //   {eid:1,ename:"abc",desg:"manager"},
    //   {eid:2,ename:"xyz",desg:"Team Lead"},
    //   {eid:3,ename:"sam",desg:"Traniee"},
    //   {eid:4,ename:"abc_nas",desg:"manager"},
    //   {eid:5,ename:"cam",desg:"Team Lead"},
    //   {eid:6,ename:"jam",desg:"Team Lead"}
    // ];
    // empdet:employee[]=this.empObj;

    // onempchange(evnt:any){
    
    //   console.log("onempchange",evnt.target.value)
    //   this.empdet=this.empObj.filter(item => item.desg == evnt.target.value)    // Returns [32, 33, 40]

    // }
}
class employee{
  eid:number=0;
  ename:string="";
  desg:string="";
}