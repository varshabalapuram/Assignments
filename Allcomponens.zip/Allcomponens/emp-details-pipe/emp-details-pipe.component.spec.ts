import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpDetailsPipeComponent } from './emp-details-pipe.component';

describe('EmpDetailsPipeComponent', () => {
  let component: EmpDetailsPipeComponent;
  let fixture: ComponentFixture<EmpDetailsPipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpDetailsPipeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpDetailsPipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
