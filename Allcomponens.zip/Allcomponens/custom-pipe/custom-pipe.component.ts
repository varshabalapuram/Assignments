import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-pipe',
  templateUrl: './custom-pipe.component.html',
  styleUrls: ['./custom-pipe.component.css']
})
export class CustomPipeComponent  {
  star_count:number[]=[1,2,3,4,5];
  max:number=10000;
  min:number=1000;
 
  salary_array:number[]=[1000,2000,3000,4000,5000,6000,7000,8000,9000,10000]

  public usersArray:any[]  =
  [
    {sid:1,uname  :  "Smith",  grade:  "1",sal:9000,card:"123456789"},
    {sid:2,uname  :  "Scott",  grade:  "2",sal:7000,card:"243345678"},
    {sid:3,uname  :  "Nancy",  grade:  "4",sal:6000,card:"242344567"},
    {sid:4,uname  :  "Ruth",  grade:  "5",sal:10000,card:"803453243"},
    {sid:5,uname  :  "Adam",  grade:  "1",sal:5000,card: "342245678"},
    {sid:6,uname  :  "Sam",  grade:  "3",sal:4000,card:"678456789"},
    {sid:7,uname  :  "Nik",  grade:  "5",sal:3000,card:"783456789"},
    {sid:8,uname  :  "Jerry",  grade:  "5",sal:1000,card:"893456789"},
    {sid:9,uname  :  "Kat",  grade:  "4",sal:2000,card:"453456789"},


  ];
  validate_range(){
    if(this.max<this.min){
       alert("Please select max value less then min")
       this.max=10000;
      this.min=1000;
    }
  }

}
