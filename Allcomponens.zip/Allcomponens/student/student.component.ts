import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  isdisabled:boolean=false;
  stud_id:number=0;
  stud_name:string="";
  age:number=0;
  course:string=""
  email:string="";
  result:string=""
  isDisabled:boolean=false;

  public studentarr:student[] = [];
 
  
  constructor() { }

  getStud_click()
  {
    this.studentarr=[
      {sid:1,sname:"studuct1",age:400,course:"c1",email:"abc@gmail.com"},
      {sid:2,sname:"studuct2",age:300,course:"c2",email:"aas@gmail.com"},
      {sid:3,sname:"studuct3",age:4400,course:"c3",email:"sdasa@gmail.com"}
    ]
  }

  ngOnInit(): void {
  }
  addstud_click()
  {
    let studObj:student = new student();
    studObj.sid = this.stud_id;
    studObj.sname = this.stud_name;
    studObj.age = this.age;
    studObj.course = this.course;
    studObj.email = this.email;
    if(this.studentarr.findIndex(   item =>  item.sid == this.stud_id )==-1){
      this.studentarr.push(studObj);
      this.clearFields();
    }
      else{
        alert("student id already exists")
      }
    
  }

  removestud_click(sno:number)
  {
    let index  =  this.studentarr.findIndex(   item =>  item.sid == sno    );
    this.studentarr.splice(index,  1);
    this.clearFields();

  }


  selectstud_click(sno:number)
  {
		let studObj:any =  this.studentarr.find(   item =>  item.sid == sno    );
		this.stud_id =   studObj.sid;
		this.stud_name =   studObj.sname;
		this.age 		=  studObj.age;
    this.course 		=  studObj.course;
    this.email 		=  studObj.email;


    this.isDisabled = true;
  }

  updatestud_click()
  {
    let index  =  this.studentarr.findIndex(   item =>  item.sid == this.stud_id    );
   
    this.studentarr[index].sname = this.stud_name;
    this.studentarr[index].age = this.age;
    this.studentarr[index].course = this.course;
    this.studentarr[index].email = this.email;
    
        this.isDisabled = false;

    this.clearFields();

  }

  clearFields()
  {
      this.isDisabled = false;
      this.stud_id = 0;
      this.stud_name  = "";
      this.age  = 0;
      this.course  = "";
      this.email='';

  }




}
class student{
    sid:number=0;
    sname:string="";
    age:number=0;
    course:string="";
    email:string="";
}