export class product{
    pid:number=0;
    pname:string="";
    price:number=0;
    category:string="";
    qty:number=0;

}

