import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DataServiceService } from '../data-service.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {

  public email: string = "varsha@gmail.com";
  public password: string = "varsha123";
  public result: string = "";
  userObj:any={}
  disable_login=false;
  disable_logout=false;

  constructor(private router: Router, private activatedRoute: ActivatedRoute,private serviceObj:DataServiceService,private httpObj:HttpClient) { }


  login_click()
  {
    
     let requestedUrl = this.activatedRoute.snapshot.queryParams["returnUrl"];

     if(requestedUrl == "" || requestedUrl == null)
     {
       requestedUrl = "/";
     }

     this.userObj = {email:this.email, password:this.password };

     this.httpObj.post<any>("http://localhost:5000/login",this.userObj).subscribe((res:any) =>

       {

         sessionStorage.setItem("AUTH_TOKEN",  res.accessToken);

         this.router.navigate([requestedUrl]);          },



         (error)=> {

           this.result  ="Invalid user id or password";

         })

 }


}
